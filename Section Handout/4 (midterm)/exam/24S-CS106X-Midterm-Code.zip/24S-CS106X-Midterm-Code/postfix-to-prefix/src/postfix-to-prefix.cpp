/*
 * Program: prefix-to-postfix.cpp
 * ------------------------------
 * Implements a program that knows how to convert
 * prefix expressions to postfix expressions.
 */

#include <iostream>
#include <cassert>
#include "console.h"
#include "simpio.h"
#include "error.h"
#include "stack.h"
using namespace std;

/*
 * Function: prefixToPostfix
 * -------------------------
 * Converts single digit prefix expressions (e.g. "*-2+46-+259") to postfix
 * expressions (e.g. "246+-25+9-*").
 */
static string prefixToPostfix(const string& prefix) {
    Stack<string> partials;
    for (int i = prefix.size() - 1; i >= 0; i--) {
        string ch = prefix.substr(i, 1);
        assert(ch.size() == 1);
        if (isdigit(ch[0])) {
            partials.push(ch);
        } else {
            if (partials.size() < 2) error("Invalid prefix expression.");
            string first = partials.pop();
            string second = partials.pop();
            partials.push(first + second + ch);
        }
    }
    cout << "and here" << endl;
    if (partials.size() != 1) error("Invalid prefix expression.");
    return partials.pop();
}

/**
 * Interactive read-eval-print loop in place to exercise
 * the above functionality.
 */
int main() {
    setConsoleFont("Courier-BOLD-24");
    cout << "Welcome to our prefix to postfix converter!" << endl;
    while (true) {
        string response = getLine("Expression? ");
        if (response == "") break;
        try {
            string result = prefixToPostfix(response);
            cout << response << " is equivalent to " << result << "." << endl;
        } catch (ErrorException ex) {
            cout << "There were problems the supplied expression." << endl;
            cout << "Error: " << ex.getMessage() << endl;
            cout << "Please try again." << endl;
        }
    }
    cout << "Thank you for playing!" << endl;
    return 0;
}
