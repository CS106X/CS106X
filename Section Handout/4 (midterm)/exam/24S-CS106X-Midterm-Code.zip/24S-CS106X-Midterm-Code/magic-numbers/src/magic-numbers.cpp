/*
 * Program: prefix-to-postfix.cpp
 * ------------------------------
 * Implements a program that knows how to convert
 * prefix expressions to postfix expressions.
 */

#include <iostream>
#include <cassert>
#include "console.h"
#include "set.h"
#include "strlib.h"
using namespace std;

/*
 * Recursive function: generateMagicNumbers
 * ----------------------------------------
 * Works to generate all permutations of the first ten digits, except
 * that it prunes those when the relevant prime number fails
 * to perfectly divide into the working permutations last three digits.
 */
static const Vector<int> kPrimes({2, 3, 5, 7, 11, 13, 17});
static void generateMagicNumbers(Set<long long>& numbers,
                                 const string& committed, const string& rest) {
    if (committed.size() > 3 &&
        stoll(committed) % 1000 % kPrimes[committed.size() - 4] > 0) return;

    if (rest.empty()) {
        numbers.add(stoll(committed));
        return;
    }

    for (int i = 0; i < rest.size(); i++) {
        generateMagicNumbers(numbers, committed + rest[i],
                             rest.substr(0, i) + rest.substr(i + 1));
    }
}

/*
 * Function: generateMagicNumbers
 * ------------------------------
 * Utility function that synthesizes all of the ten-digit magic numbers
 * as outlined in the midterm handout.
 */
static void generateMagicNumbers(Set<long long>& numbers) {
    generateMagicNumbers(numbers, "", "1234567890");
}


/**
 * Interactive read-eval-print loop in place to exercise
 * the above functionality.
 */
int main() {
    setConsoleFont("Courier-BOLD-24");
    Set<long long> numbers;
    generateMagicNumbers(numbers);
    cout << "Here there are:" << endl;
    for (const long long& n: numbers) cout << " + " << n << endl;
    cout << "And that's that!" << endl;
    return 0;
}
