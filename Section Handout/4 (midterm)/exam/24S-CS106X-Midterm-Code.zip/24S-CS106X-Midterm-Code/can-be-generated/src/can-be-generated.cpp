/*
 * Program: prefix-to-postfix.cpp
 * ------------------------------
 * Implements a program that knows how to convert
 * prefix expressions to postfix expressions.
 */

#include <iostream>
#include <cassert>
#include "console.h"
#include "vector.h"
#include "map.h"
#include "strlib.h"
using namespace std;

/*
 * Recursive Function: cbg
 * -----------------------
 * cbg (short for canBeGenerated) searched the provided grammar to see whether or not
 * the provided string to be matched (called tbm, for to be matched) can be generated
 * from the provided working production (called wp, for working production).
 *
 * If the working production doesn't contain any non terminals, then we immediately
 *   return true iff the working production has evolved to perfectly match tbm.
 * Otherwise, we confirm that everything up through the opening '<' of the working production
 *   matches the beginning of tbm, else we return false immediately.
 *
 * Otherwise, we frame the original problem in terms of new working productions where
 *   the first nonterminal is replaced by all of its possible expansions.  If any one
 *   of them works out, we return true.  If none of them work out, we ultimately return false.
 */
static bool cbg(Map<string, Vector<string>>& g, const string& tbm, const string& wp) {
    int start = wp.find('<');
    if (start == string::npos) return wp == tbm;

    string prefix = wp.substr(0, start);
    if (!startsWith(tbm, prefix)) return false;

    string suffix = tbm.substr(prefix.length());
    int end = wp.find('>', start + 1);
    string nonterminal = wp.substr(start, end - start + 1);
    string rest = wp.substr(end + 1);

    const Vector<string>& productions = g[nonterminal];
    for (const string& production: productions) {
        if (cbg(g, suffix, production + rest)) {
            return true;
        }
    }

    return false;
}

/*
 * Function: cbg
 * -------------
 * Returns true if and only if the supplied sentence can be generated from the
 * supplied context-free grammar.
 */
static bool cbg(Map<string, Vector<string> >& g, const string& sentence) {
    return cbg(g, sentence, "<start>");
}

/**
 * Interactive read-eval-print loop in place to exercise
 * the above functionality.
 */
int main() {
    Map<string, Vector<string>> g;
    g["<start>"] += "The <object> <verb> tonight.";
    g["<object>"] += "waves", "big yellow flowers", "slugs";
    g["<verb>"] += "sigh <adverb>", "portend like <object>", "portend like <object> <object>", "die <adverb>";
    g["<adverb>"] += "warily", "grumpily";
    assert(cbg(g, "The slugs die warily tonight."));
    assert(!cbg(g, "!The slugs die warily tonight.."));
    assert(cbg(g, "The slugs portend like slugs tonight."));
    assert(cbg(g, "The slugs portend like slugs slugs tonight."));
    cout << "No issues!" << endl;
    return 0;
}
